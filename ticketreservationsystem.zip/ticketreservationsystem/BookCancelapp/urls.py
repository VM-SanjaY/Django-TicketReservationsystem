from django.urls import path
from . import views


urlpatterns = [
    path('',views.homepage,name='homepage'),
    path('home/',views.home,name='home'),
    path('bookhome/',views.bookhome,name='bookhome'),
    path('flightavail/',views.flightavail,name='flightavail'),
    path('bookflight/',views.bookflight,name='bookflight'),
    path('statuscheck/',views.statuscheck,name='statuscheck'),
    path('cancelpage/',views.cancelpage,name='cancelpage'),
    path('fullcancel/',views.fullcancel,name='fullcancel'),
    path('customcancel/',views.customcancel,name='customcancel'),
]