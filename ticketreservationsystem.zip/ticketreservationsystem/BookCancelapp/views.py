from django.shortcuts import render, redirect
from BookCancelapp.models import *
from django.contrib import messages
import mysql.connector

mydb = mysql.connector.connect( host="localhost",user="root",password="root", database="ticketreservationsystems")
mycursor = mydb.cursor()




def homepage(request):
    return render(request,'project/mainbody.html')

def home(request):
    return render(request,'project/homepage.html',)

def bookhome(request):
    return render(request,'project/bookhome.html')

def flightavail(request):
    mycursor.execute('select * from destinatiom')
    myresult = mycursor.fetchall()
    return render(request,'project/flightavail.html',{'myresult':myresult})

def bookflight(request):
    if request.method == "POST":
        From = request.POST.get('From')
        ticket = request.POST.get('nooftickets')
        name = request.POST.get('name')
        ticket = int(ticket)
        if ticket > 0:
            data = Booking(From =From,ticket =ticket,name=name)
            data.save()
            messages.success(request,"Data added successfully")
            return redirect('home')

    return render(request,'project/bookflight.html')


def statuscheck(request):
    mycursor.execute('select * from bookcancelapp_booking')
    myresult = mycursor.fetchall()
    return render(request,'project/statuscheck.html',{'myresult':myresult})


def cancelpage(request):
    return render(request,'project/cancelpage.html')


def fullcancel(request):
    mycursor.execute('select * from bookcancelapp_booking')
    myresult = mycursor.fetchall()
    if request.method == "POST":
        cancelall = request.POST.get('cancelall')
        if cancelall == 'yes':
            mycursor.execute('delete from bookcancelapp_booking')
            mydb.commit()
            messages.success(request,"Ticket cancelled successfully")
            return redirect('home')
    return render(request,'project/fullcancel.html',{'myresult':myresult})

def customcancel(request):
    mycursor.execute('select * from bookcancelapp_booking')
    myresult = mycursor.fetchall()
    if request.method == "POST":
        ticket = request.POST.get('nooftickets')
        ID = request.POST.get('name')
        ticket = int(ticket)
        ID = int(ID)
        ticketcount = ("Select ticket from bookcancelapp_booking where id = %s")
        mycursor.execute(ticketcount, (ID,))
        myresult = mycursor.fetchall()
        for y in myresult:
            y = int(y[0])
        if ticket > y:
            messages.info(request,"Please mention the correct amount of ticket you want to cancel")
            return redirect('customcancel')     
        elif ticket == y:
            deleteticket = ('delete from bookcancelapp_booking where id = %s')
            mycursor.execute(deleteticket, (ID,))
            mydb.commit()
            messages.success(request,"Ticket cancelled successfully")
            return redirect('home')
        elif ticket < y:
            result = (y - ticket)
            newresult = (result,ID)
            up = "UPDATE bookcancelapp_booking SET ticket = %s WHERE id = %s"
            mycursor.execute(up, newresult)
            mydb.commit()
            messages.success(request,"Ticket cancelled successfully")
            return redirect('home')
    return render(request,'project/customcancel.html',{'myresult':myresult})   