from django.db import models
from django.contrib.auth.models import User



class Public_users(models.Model):
      id=models.AutoField(primary_key=True)
      user=models.OneToOneField(User, null=False, on_delete=models.CASCADE)
      name=models.CharField(max_length=50, blank=False)
      username=models.CharField(max_length=50, blank=False)
      phone_no=models.CharField(max_length=12, blank=False)
      email=models.CharField(max_length=50, blank=False)
      password=models.CharField(max_length=50, blank=False)
      created_at = models.DateTimeField(auto_now_add=True)
      updated_at = models.DateTimeField(auto_now_add=True)
      objects=models.Manager()

      def __str__(self):
            return self.user.username











