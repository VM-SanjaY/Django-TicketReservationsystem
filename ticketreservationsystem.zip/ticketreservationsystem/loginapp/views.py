from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login as auth_login, logout
from loginapp.models import *
from django.contrib import messages
import mysql.connector

mydb = mysql.connector.connect( host="localhost",user="root",password="root", database="ticketreservationsystems")
mycursor = mydb.cursor()


def loginpage(request):
    if request.method == "POST":
        email = request.POST.get('email')
        password = request.POST.get('password')
        val = (password, email)
        check = "SELECT username FROM loginapp_public_users WHERE password = %s AND email = %s"
        mycursor.execute(check, val)
        myresult = mycursor.fetchall()
        if myresult:
            return redirect('homepage/home')
     
            
       
    return render(request,'project/logintemplate.html')


def registerpage(request):
    if request.method == "POST":
        name = request.POST.get('name')
        username= request.POST.get('username')
        phonenumber= request.POST.get('phonenumber')
        email= request.POST.get('email')
        password = request.POST.get('password')
        confirmpassword = request.POST.get('confirmpassword')
        print(confirmpassword,password,phonenumber,name,username)
        if password == confirmpassword:
            if User.objects.filter(username=username).exists():
                messages.info(request,"Username already exist")
                return redirect('register')
            else:
                if User.objects.filter(email=email).exists():
                    messages.info(request,"Email ID already exist")
                    return redirect('register')
                else:
                    user = User.objects.create_user(email=email,username=username,password=password)
                    user.save()
                    data = Public_users(user=user,name=name,username=username,phone_no=phonenumber,email=email,password=password)
                    data.save()
                    messages.success(request,"Data added successfully")     
                    return redirect('/')

        else:
            print("pass not match")
            messages.info(request,"password does not match")
            return redirect('register')
              
        
    return render(request,'project/registertemplate.html')


def forgotpage(request):
    global email
    if request.method == "POST":
        email = request.POST.get('email')
        check = "SELECT username FROM loginapp_public_users WHERE email = %s"
        mycursor.execute(check, (email,))
        myresult = mycursor.fetchall()
        if myresult:
            return redirect('setpassword')
    return render(request,'project/forgottemp.html')



def setpasswordpage(request):
    if request.method=="POST":
        password=request.POST.get('password')
        confirmpassword=request.POST.get('confirmpassword')
        val = (password, email)
        if password == confirmpassword:
            alterpass = "UPDATE loginapp_public_users SET password = %s WHERE email = %s"
            mycursor.execute(alterpass, val)
            mydb.commit()
            return redirect('/')
        else:
            messages.info(request,"password does not match")
            return redirect('setpassword')

    return render(request,'project/setpassword.html')



def logoutpage(request):
    logout(request)
    return redirect('/')
